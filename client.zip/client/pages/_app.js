import 'bootstrap/dist/css/bootstrap.css';
import buildClient from '../api/build-client';
import Header from '../components/header';

// pagesフォルダのファイルをまとめて受け取り、global cssを適用する
const AppComponent = ({ Component, pageProps, currentUser }) => {
  return (
    <div>
      <Header currentUser={currentUser} />
      <div className='container'>
        <Component currentUser={currentUser} {...pageProps} />
      </div>
    </div>
  );
};

// Custom App Componentのcontext = { Component, ctx:{ req,res }}
// Page Componentの      context = { req, res }
// App ComponentでgetInitalPropsを使うと、Page ComponentのgetInitialPropsは自動で呼ばれなくなる
AppComponent.getInitialProps = async (appContext) => {
  // console.log(Object.keys(appContext)); //  [ 'AppTree', 'Component', 'router', 'ctx' ]
  // console.log(appContext);
  const client = buildClient(appContext.ctx);
  const { data } = await client.get('/api/users/currentuser');

  let pageProps = {};
  if (appContext.Component.getInitialProps) {
    pageProps = await appContext.Component.getInitialProps(
      appContext.ctx,
      client,
      data.currentUser
    );
  }

  return {
    pageProps,
    ...data,
  };
};

export default AppComponent;
