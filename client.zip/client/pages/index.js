// pages/indexがLanding Pageと扱われる(Next) : http://localhost:3000
// pagesフォルダ配下のファイルがrouter扱い(Next) : http://localhost:3000/banana

import Link from 'next/link';

// getInitialPropsのreturn objectをpropsで使える
// server side renderingでは、componentの中ではdata fetchできない
// ブラウザ上で実行される(ticketing/dev/のdomainを推測して実行される)
const LandingPage = ({ currentUser, tickets }) => {
  // chrome F12 => consoleの右端のapplication => Cookie => clearでsignoutテスト

  const ticketList = tickets.map((ticket) => {
    return (
      <tr key={ticket.id}>
        <td>{ticket.title}</td>
        <td>{ticket.price}</td>
        <td>
          <Link href='/tickets/[ticketId]' as={`/tickets/${ticket.id}`}>
            <a>View</a>
          </Link>
        </td>
      </tr>
    );
  });

  return (
    <div>
      <h1>Tickets</h1>
      <table className='table'>
        <thead>
          <tr>
            <th>Title</th>
            <th>Price</th>
            <ht>Link</ht>
          </tr>
        </thead>
        <tbody>{ticketList}</tbody>
      </table>
    </div>
  );
};

// Ingress Nginxサーバー上で実行される(k8 podのcontainerのport上)
// domainを省略するとlocalhostで実行される(ticketing/devではない)
// http://auth-srv/api/users/currentuserとする必要がある => ingress nginxに渡すことで推測してくれる(cross namespaces)

// App ComponentでgetInitalPropsを使うと、ここは自動で呼ばれなくなる
// ({req}) => contextでok(第一引数)
LandingPage.getInitialProps = async (context, client, currentUser) => {
  const { data } = await client.get('/api/tickets');

  return { tickets: data };
};

export default LandingPage;
