// 起動時に読み込まれる
// file変更を300msごとに検知できる(skaffoldで自動検知できてなくても300msごとにここで検知)

// 再読み込みには、kubectl get pods => kubectl delete pod <pod名> で自動再作成
module.exports = {
  webpackDevMiddleware: (config) => {
    config.watchOptions.poll = 300;
    return config;
  },
};
