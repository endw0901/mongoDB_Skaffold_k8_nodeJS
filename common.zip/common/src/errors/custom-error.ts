// interfaceのかわりにabstractをつかってタイプチェックに使う

export abstract class CustomError extends Error {
  abstract statusCode: number;

  constructor(message: string) {
    super(message);

    Object.setPrototypeOf(this, CustomError.prototype);
  }

  // object配列をもつ
  abstract serializeErrors(): { message: string; field?: string }[];
}
