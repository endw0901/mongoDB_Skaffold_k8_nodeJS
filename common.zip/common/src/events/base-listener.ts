import nats, { Message, Stan } from 'node-nats-streaming';
// type定義：Message => getSubject(ticket:createdなど), getSequence(event番号), getData(publisherからくるdata)
import { Subjects } from './subjects';

interface Event {
  subject: Subjects;
  data: any;
}

export abstract class Listener<T extends Event> {
  abstract subject: T['subject'];
  abstract queueGroupName: string;
  abstract onMessage(data: T['data'], msg: Message): void;
  protected client: Stan;
  protected ackWait = 5 * 1000;

  constructor(client: Stan) {
    this.client = client;
  }

  // DeliverAllAvailableは全部受けなおすが、DurableNameはprocess済みかどうかを分けてくれる。subscribe第二引数のqueue-groupがあると、
  // durable情報を再起動時に消さずに残してくれるので、restartのたびに全部受けなおさなくなる
  // ManualActMode(true) => acknowledgeが得られなければほかのlistenerへ
  subscriptionOptions() {
    return this.client
      .subscriptionOptions()
      .setDeliverAllAvailable()
      .setManualAckMode(true)
      .setAckWait(this.ackWait)
      .setDurableName(this.queueGroupName);
  }

  // subscribe引数:subject, QueueGroup, options
  // 同一QueueGroupの複数listenerのうち、いずれか一つだけが受け取る（分散される
  listen() {
    const subscription = this.client.subscribe(
      this.subject,
      this.queueGroupName,
      this.subscriptionOptions()
    );

    subscription.on('message', (msg: Message) => {
      console.log(`Message received: ${this.subject} / ${this.queueGroupName}`);

      const parsedData = this.parseMessage(msg);
      this.onMessage(parsedData, msg);
    });
  }

  // bufferの場合はutf8にしてJSONを取り出す・・らしい
  parseMessage(msg: Message) {
    const data = msg.getData();
    return typeof data === 'string'
      ? JSON.parse(data)
      : JSON.parse(data.toString('utf8'));
  }
}
