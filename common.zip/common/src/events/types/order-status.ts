export enum OrderStatus {
  // 注文作成済み（チケット未予約）
  Created = 'created',

  // 1.注文したチケットが予約済み（自動キャンセル）
  // 2.自分でキャンセル
  // 3.注文の有効期限切れ（自動キャンセル）
  Cancelled = 'cancelled',

  // チケット予約成功・支払い未済
  AwaitingPayment = 'awaiting:payment',

  // 支払い済み
  Complete = 'complete',
}
