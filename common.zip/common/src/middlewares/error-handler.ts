import { Request, Response, NextFunction } from 'express';
import { CustomError } from '../errors/custom-error';

export const errorHandler = (
  err: Error,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // err.serializeErrorなどとすることで、個別のerror側に個別の責任を持たせる(typeガードはabstract classのcustom-errorで行う)
  if (err instanceof CustomError) {
    return res.status(err.statusCode).send({ errors: err.serializeErrors() });
  }

  // CustomErrorでとらえられなかったときの原因調査用
  console.error(err);

  res.status(400).send({
    errors: [{ message: 'Something went wrong' }],
  });
};
