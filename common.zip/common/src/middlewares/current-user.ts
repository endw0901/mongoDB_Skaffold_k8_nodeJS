import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

interface UserPayload {
  id: string;
  email: string;
}

// 既存のtype definitionに追加
declare global {
  namespace Express {
    interface Request {
      currentUser?: UserPayload;
    }
  }
}

export const currentUser = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // 概要：userがsign inしてたらpayloadを返す

  // cookieが存在しない or jwtが存在しない場合はエラー
  // if (!req.session || !req.session.jwt) {と等しいtypescript構文
  if (!req.session?.jwt) {
    // return res.send({ currentUser: null });
    return next();
  }

  // jwtのチェック
  try {
    const payload = jwt.verify(
      req.session.jwt,
      // sign in key(yaml記載のenv変数を参照)
      // index.tsで存在なしチェックをしてるので、ここではtypeガード迂回の!を指定
      process.env.JWT_KEY!
    ) as UserPayload;
    // requestに追加のpropertyを加えてpayloadを設定して返す
    req.currentUser = payload;
    // res.send({ currentUser: payload });
  } catch (err) {
    // res.send({ currentUser: null });
  }

  next();
};
